
Whenever you interact with a mailbox, the bank, the auction house,
a merchant or trade with anoter player, this add-on opens all
your bags.

This was inspired by the existing OpenBags add-on which did not
work together with "Soul Pouch".

*** Changelog

Version 1
Initial release
