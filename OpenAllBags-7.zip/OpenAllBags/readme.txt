
Whenever you interact with a mailbox, the bank, the auction house,
a merchant or trade with another player, this add-on opens all
your bags.

This was inspired by the existing OpenBags add-on which did not
work together with "Soul Pouch".

*** Changelog

Version 7
 * Updated TOC for WoW 4.0.1

Version 6
 * Updated TOC for WoW 3.3.5
 * Removed an unused function.
 * No longer use an XML file.

Version 5
 * Updated TOC for WoW 3.2
 * Added license information
 * Added link to project main page at
   http://code.google.com/p/open-all-bags/

Version 4
 * Updated TOC for WoW 3.1.2

Version 3
 * Updated TOC for WoW 3.0.2

Version 2
 * Added support for guild bank (reported by Greymalkin)
 * Removed unused code (reported by Greymalkin)

Version 1
* Initial release
